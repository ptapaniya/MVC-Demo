//
//  SubCategoryTVCell.swift
//  MVC
//
//  Created by Prakash on 16/05/20.
//  Copyright © 2020 Prakash. All rights reserved.
//

import UIKit
import Kingfisher

class SubCategoryTVCell: UITableViewCell {

    @IBOutlet weak var lblcategoryName: UILabel!
    @IBOutlet weak var clvPack: UICollectionView!
        
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        lblcategoryName.sizeToFit()
        
       // self.lblcategoryName.layer.borderColor = UIColor.black.cgColor
       // self.lblcategoryName.layer.borderWidth = 1.5
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
 
}
