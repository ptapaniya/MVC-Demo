//
//  clvPackCell.swift
//  MVC
//
//  Created by Prakash on 17/05/20.
//  Copyright © 2020 Prakash. All rights reserved.
//

import UIKit

class clvPackCell: UICollectionViewCell {

    @IBOutlet weak var imgPack: UIImageView!
    @IBOutlet weak var lblPack: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        self.contentView.layer.borderColor = UIColor.black.cgColor
        self.contentView.layer.borderWidth = 1.5
    }

}
