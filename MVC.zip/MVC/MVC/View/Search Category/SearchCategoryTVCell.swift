//
//  SearchCategoryTVCell.swift
//  MVC
//
//  Created by Prakash on 27/05/20.
//  Copyright © 2020 Prakash. All rights reserved.
//

import UIKit

class SearchCategoryTVCell: UITableViewCell {

    @IBOutlet weak var lblCategory: UILabel!
   
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
