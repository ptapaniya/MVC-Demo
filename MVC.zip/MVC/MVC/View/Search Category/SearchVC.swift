//
//  SearchVC.swift
//  MVC
//
//  Created by Prakash on 27/05/20.
//  Copyright © 2020 Prakash. All rights reserved.
//

import UIKit

class SearchVC: UIViewController,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate,UITextFieldDelegate {
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tblCategory: UITableView!
    @IBOutlet weak var txtSearchbar: UITextField!
    
    var arrCategory = [DataMain]()
    var arrFilter = [DataMain]()
    var search : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
                
        txtSearchbar.delegate = self
        
        arrFilter = arrCategory
        tblCategory.reloadData()
        
        
        // Do any additional setup after loading the view.
    }
    
    // TABLEVIEW DELEGATE AND DATA SOURCE METHOD
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrFilter.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
        let cell = tableView.dequeueReusableCell(withIdentifier: "SearchCategoryTVCell", for: indexPath) as! SearchCategoryTVCell
        
        let dict = arrFilter[indexPath.row]
        
        cell.lblCategory.text = dict.packMainName
                
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let dict = arrFilter[indexPath.row]
        let packList = dict.packlist[indexPath.row]
        let imgURL = URL(string: packList.packImage)
                
        // Create Folder in Document Directory
        createDirectory(folderName: packList.packName)
        
        // Get Document Directory Path
        let newURL = getDirectoryPath().appendingPathComponent(packList.packName)
        if let data = try? Data.init(contentsOf: imgURL!) {
            if let img = UIImage(data: data)
            {
                // Get Image From Document Directory
                let image = getImage(imageName: packList.packName)
                
                // Save Image In Document Directory
                saveImageToDocumentDirectory(image: img, imageName: "\(packList.packName).png", newDir : newURL as NSString)
            }
        }
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        let dict = arrFilter[indexPath.row]
        let packList = dict.packlist[indexPath.row]
        
        // Delete Image From Document Directory
        deleteDirectory(directoryName: packList.packName, documentDir: getDirectoryPath().appendingPathComponent(packList.packName) as NSString)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50.0
    }
    
     
    // SEARCHBAR DELEGATE METHOD
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        arrFilter = searchText.isEmpty ? arrCategory : arrCategory.filter { item in
            
            return (item.packMainName).range(of: searchText, options: .caseInsensitive, range: nil, locale: nil) != nil
        }
        
        tblCategory.reloadData()

    }
    
    // TEXTFIELD DELEGATE METHOD

    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    {
        let searchText = textField.text! + string
        
        if searchText.count >= 0
        {
            arrFilter = searchText.isEmpty ? arrCategory : arrCategory.filter { item in
                
                return (item.packMainName).range(of: searchText, options: .caseInsensitive, range: nil, locale: nil) != nil
            }
        }else{
            arrFilter = arrCategory
        }
        
        tblCategory.reloadData()
        
        return true
    }
}
