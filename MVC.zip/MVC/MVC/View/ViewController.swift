//
//  ViewController.swift
//  MVC
//
//  Created by Prakash on 16/05/20.
//  Copyright © 2020 Prakash. All rights reserved.
//

import UIKit
import Alamofire

class ViewController: UIViewController {
    
    @IBOutlet weak var clvCategory: UICollectionView!
    @IBOutlet weak var tblCategory: UITableView!
    
    var arrCategory = [DataMain]()
    var allDtata : RootClass!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        clvCategory.register(UINib(nibName: "categoryCVCell", bundle: nil), forCellWithReuseIdentifier: "categoryCVCell")
        tblCategory.register(UINib(nibName: "SubCategoryTVCell", bundle: nil), forCellReuseIdentifier: "SubCategoryTVCell")
        
        HomePack()
    }
    
    func jsonToString(json: AnyObject) -> String? {
        do {
            let data1 =  try JSONSerialization.data(withJSONObject: json, options: JSONSerialization.WritingOptions.prettyPrinted) // first of all convert json to the data
            let convertedString = String(data: data1, encoding: String.Encoding.utf8) // the data will be converted to the string
            print(convertedString ?? "") // <-- here is ur string
            
            return convertedString
            
        } catch let myJSONError {
            print(myJSONError)
            return nil
        }
    }
    
    //MARK:- API Calling
    func HomePack() {
        
        AF.request("\(BaseURL)HomePack", method: .get, parameters: nil, encoding: JSONEncoding.default)
            .responseJSON { response in
                // print(response)
                //to get status code
                if let status = response.response?.statusCode {
                    switch(status){
                    case 200:
                        
                        if let data = try? JSONSerialization.data(withJSONObject: response.value! as AnyObject, options: .prettyPrinted)
                        {
                            if let dataDict = try? JSONDecoder().decode(RootClass.self, from: data)
                            {
                                self.allDtata = dataDict
                                self.arrCategory = self.allDtata.data
                                
                                self.clvCategory.reloadData()
                                self.tblCategory.reloadData()
                            }
                        }
                        
                    default:
                        print("error with response status: \(status)")
                    }
                }
        }
    }
    
    func callsendImageAPI(_ img : UIImage?) {
        
        let headers: HTTPHeaders
        headers = ["Content-type": "multipart/form-data",
                   "Content-Disposition" : "form-data"]
        
        let param = ["device_id": "123456",
                     "user_id": "123456",
                     "pack_name": "TEst",
                     "description": "Test Desctiption",
                     "status": "true",
                     "is_premium": "0"] as NSDictionary
        
        AF.upload(multipartFormData: { (multipartFormData) in
            
            for (key, value) in param {
                multipartFormData.append((value as! String).data(using: String.Encoding.utf8)!, withName: key as! String)
            }
            
            guard let imgData = img?.jpegData(compressionQuality: 1) else { return }
            multipartFormData.append(imgData, withName: "cover_iamge", fileName: "\(String(describing: Date().currentTimeMillis))" + ".jpeg", mimeType: "image/jpeg")
            
            
        },to: "http://139.59.92.46/sticker_maker/public/api/create_pack").response{ response in
            
            if((response.error != nil)){
                do{
                    if let jsonData = response.data{
                        let parsedData = try JSONSerialization.jsonObject(with: jsonData) as! Dictionary<String, AnyObject>
                        print(parsedData)
                        
                        //                        let status = parsedData[] as? NSInteger ?? 0
                        //
                        //                        if (status == 1){
                        //                            if let jsonArray = parsedData["data"] as? [[String: Any]] {
                        //                                withblock(jsonArray as AnyObject)
                        //                            }
                        //
                        //                        }else if (status == 2){
                        //                            print("error message")
                        //                        }else{
                        //                            print("error message")
                        //                        }
                    }
                }catch{
                    print("error message")
                }
            }else{
                print(response.error!.localizedDescription)
            }
        }
    }
}

extension ViewController : UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout
{
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == clvCategory
        {
            return arrCategory.count
        }else{
            
            let dict = arrCategory[collectionView.tag]
            return dict.packlist.count
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if collectionView == clvCategory
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "categoryCVCell", for: indexPath) as! categoryCVCell
            
            let dict = arrCategory[indexPath.row]
            cell.lblCategory.text = dict.packMainName
            
            return cell
            
        }else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "clvPackCell", for: indexPath) as! clvPackCell
            
            let dict = arrCategory[collectionView.tag]
            let packList = dict.packlist[indexPath.item]
            let imgURL = URL(string: packList.packImage)
            cell.lblPack.text = packList.packName
            cell.imgPack.kf.setImage(with: imgURL)
            
            return cell
            
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if collectionView != clvCategory
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "clvPackCell", for: indexPath) as! clvPackCell
          
            let dict = arrCategory[collectionView.tag]
            let packList = dict.packlist[indexPath.item]
            let imgURL = URL(string: packList.packImage)
            
            if let data = try? Data(contentsOf: imgURL!)
            {
                let image: UIImage = UIImage(data: data)!
                callsendImageAPI(image)
            }
                        
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: 100.0, height: collectionView.frame.height)
        
    }
}

extension ViewController : UITableViewDelegate,UITableViewDataSource
{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.arrCategory.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "SubCategoryTVCell", for: indexPath) as! SubCategoryTVCell
        
        let dict = arrCategory[indexPath.row]
        cell.lblcategoryName.text = dict.packMainName
        
        cell.lblcategoryName.transform = CGAffineTransform(rotationAngle: -CGFloat.pi / 2)
        cell.lblcategoryName.frame = CGRect.init(x: 0, y: 0, width: 50.0, height: 159.0)
        
        self.tblCategory.setNeedsLayout()
        self.tblCategory.layoutIfNeeded()
        
        cell.clvPack.delegate = self
        cell.clvPack.dataSource = self
        cell.clvPack.tag = indexPath.row
        cell.clvPack.register(UINib(nibName: "clvPackCell", bundle: nil), forCellWithReuseIdentifier: "clvPackCell")
        cell.clvPack.reloadData()
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let SearchVC = self.storyboard?.instantiateViewController(withIdentifier: "SearchVC") as! SearchVC
        SearchVC.arrCategory = arrCategory
        self.navigationController?.pushViewController(SearchVC, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    
}
