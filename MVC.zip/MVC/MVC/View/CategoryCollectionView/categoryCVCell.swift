//
//  categoryCVCell.swift
//  MVC
//
//  Created by Prakash on 16/05/20.
//  Copyright © 2020 Prakash. All rights reserved.
//

import UIKit

class categoryCVCell: UICollectionViewCell {

    @IBOutlet weak var lblCategory: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
//        self.contentView.layer.cornerRadius = self.contentView.frame.height/2
        self.contentView.layer.borderColor = UIColor.black.cgColor
        self.contentView.layer.borderWidth = 2
    }

}
