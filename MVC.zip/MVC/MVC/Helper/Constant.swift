//
//  Constant.swift
//  MVC
//
//  Created by Prakash on 16/05/20.
//  Copyright © 2020 Prakash. All rights reserved.
//

import Foundation
import UIKit

let BaseURL = "http://139.59.92.46/sticker_maker/public/api/"


//MARK:- Document Directory
func createDirectory(folderName : String) {
    let fileManager = FileManager.default
    let paths = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent(folderName)
    if !fileManager.fileExists(atPath: paths){
        do {
            try fileManager.createDirectory(atPath: paths, withIntermediateDirectories: true, attributes: nil)
        } catch {
            print("Couldn't create document directory")
        }
    }else{
        print("Already directory created.")
    }
}

func getDirectoryPath() -> NSString {
    let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
    return paths as NSString
}

func saveImageToDocumentDirectory(image: UIImage, imageName: String, newDir : NSString) {
    let fileManager = FileManager.default
    let paths = newDir.appendingPathComponent(imageName)
    let imageData = image.jpegData(compressionQuality: 1.0)
    fileManager.createFile(atPath: paths as String, contents: imageData, attributes: nil)
}

func getImage(imageName : String) -> UIImage{
    let fileManager = FileManager.default
    // Here using getDirectoryPath method to get the Directory path
    let imagePath = (getDirectoryPath().appendingPathComponent(imageName) as NSString).appendingPathComponent("\(imageName).png")
    if fileManager.fileExists(atPath: imagePath){
        return UIImage(contentsOfFile: imagePath)!
    }else{
        print("No Image available")
        return UIImage() // Return placeholder image here
    }
}

func deleteDirectory(directoryName : String, documentDir : NSString){
    let fileManager = FileManager.default
    let paths = documentDir.appendingPathComponent("\(directoryName).png")
    if fileManager.fileExists(atPath: paths){
        try! fileManager.removeItem(atPath: paths)
    }else{
        print("Directory not found")
    }
}
