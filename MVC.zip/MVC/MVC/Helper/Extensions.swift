//
//  Extensions.swift
//  MVC
//
//  Created by Prakash on 29/05/20.
//  Copyright © 2020 Prakash. All rights reserved.
//

import Foundation
import UIKit


extension Date {
    func currentTimeMillis() -> Int64 {
        return Int64(self.timeIntervalSince1970 * 1000)
    }
}

