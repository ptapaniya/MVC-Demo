//
//  RootClass.swift
//
//  Generated using https://jsonmaster.github.io
//  Created on May 16, 2020
//
import Foundation

class RootClass: Codable {

	let ResponseCode: String
	let ResponseMessage: String
	let data: [DataMain]
	let data2: [String]

	private enum CodingKeys: String, CodingKey {
		case ResponseCode = "ResponseCode"
		case ResponseMessage = "ResponseMessage"
		case data = "data"
		case data2 = "data2"
	}

    required init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		ResponseCode = try values.decode(String.self, forKey: .ResponseCode)
		ResponseMessage = try values.decode(String.self, forKey: .ResponseMessage)
		data = try values.decode([DataMain].self, forKey: .data)
		data2 = try values.decode([String].self, forKey: .data2)
	}

	func encode(to encoder: Encoder) throws {
		var container = encoder.container(keyedBy: CodingKeys.self)
		try container.encode(ResponseCode, forKey: .ResponseCode)
		try container.encode(ResponseMessage, forKey: .ResponseMessage)
		try container.encode(data, forKey: .data)
		try container.encode(data2, forKey: .data2)
	}

}
