//
//  Data.swift
//
//  Generated using https://jsonmaster.github.io
//  Created on May 16, 2020
//
import Foundation

class DataMain: Codable {

	let packMainId: Int
	let packMainName: String
	let packlist: [Packlist]

	private enum CodingKeys: String, CodingKey {
		case packMainId = "pack_main_id"
		case packMainName = "pack_main_name"
		case packlist = "packlist"
	}

    required init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		packMainId = try values.decode(Int.self, forKey: .packMainId)
		packMainName = try values.decode(String.self, forKey: .packMainName)
		packlist = try values.decode([Packlist].self, forKey: .packlist)
	}

	func encode(to encoder: Encoder) throws {
		var container = encoder.container(keyedBy: CodingKeys.self)
		try container.encode(packMainId, forKey: .packMainId)
		try container.encode(packMainName, forKey: .packMainName)
		try container.encode(packlist, forKey: .packlist)
	}

}
