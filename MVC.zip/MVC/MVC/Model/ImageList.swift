//
//  ImageList.swift
//
//  Generated using https://jsonmaster.github.io
//  Created on May 16, 2020
//
import Foundation

class ImageList: Codable {

	let packId: Int
	let packName: String
	let packImage: String
	let isPremium: Bool
	let IsImage: Bool

	private enum CodingKeys: String, CodingKey {
		case packId = "pack_id"
		case packName = "pack_name"
		case packImage = "pack_image"
		case isPremium = "is_premium"
		case IsImage = "Is_image"
	}

    required init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		packId = try values.decode(Int.self, forKey: .packId)
		packName = try values.decode(String.self, forKey: .packName)
		packImage = try values.decode(String.self, forKey: .packImage)
		isPremium = try values.decode(Bool.self, forKey: .isPremium)
		IsImage = try values.decode(Bool.self, forKey: .IsImage)
	}

	func encode(to encoder: Encoder) throws {
		var container = encoder.container(keyedBy: CodingKeys.self)
		try container.encode(packId, forKey: .packId)
		try container.encode(packName, forKey: .packName)
		try container.encode(packImage, forKey: .packImage)
		try container.encode(isPremium, forKey: .isPremium)
		try container.encode(IsImage, forKey: .IsImage)
	}

}
