//
//  Packlist.swift
//
//  Generated using https://jsonmaster.github.io
//  Created on May 16, 2020
//
import Foundation

class Packlist: Codable {

	let packId: Int
	let packName: String
	let packImage: String
	let isGIF: Bool
	let imageList: [ImageList]

	private enum CodingKeys: String, CodingKey {
		case packId = "pack_id"
		case packName = "pack_name"
		case packImage = "pack_image"
		case isGIF = "is_GIF"
		case imageList = "image_list"
	}

    required init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		packId = try values.decode(Int.self, forKey: .packId)
		packName = try values.decode(String.self, forKey: .packName)
		packImage = try values.decode(String.self, forKey: .packImage)
		isGIF = try values.decode(Bool.self, forKey: .isGIF)
		imageList = try values.decode([ImageList].self, forKey: .imageList)
	}

	func encode(to encoder: Encoder) throws {
		var container = encoder.container(keyedBy: CodingKeys.self)
		try container.encode(packId, forKey: .packId)
		try container.encode(packName, forKey: .packName)
		try container.encode(packImage, forKey: .packImage)
		try container.encode(isGIF, forKey: .isGIF)
		try container.encode(imageList, forKey: .imageList)
	}

}
